import re

print(re.search("a.e.i.o.u","This is a test"))
