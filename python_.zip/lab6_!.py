import re
str=re.compile("a")
print(str.search("apple"))
print(re.search("b","apple"))