import re
print(re.search("^a","This is a test"))
print(re.search("$e","This is a test"))