da=["1 2 3 4 5 6 7 8"]
dareserve=["8 7 6 5 4 3 2 1"]
you=input()
list=[]
list.append(you)
if list==da:
    print("ascending")
elif list==dareserve:
    print("descending")
else:
    print("mixed")