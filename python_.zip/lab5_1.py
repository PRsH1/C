"""
주제:함수
작성일:2017.10.11.
작성자:이승현
"""
def sum(a,b):
    return a+b
s=sum(2,4)
print("합:",s)
print(sum(35,46))
