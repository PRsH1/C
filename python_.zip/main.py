import person

p=person.person("나야나",20)
print(p)
p2=person.person("나야나",50)
p3=person.person("Donald J Trump",71)
print(p==p2)
print(p==p3)
