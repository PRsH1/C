"""
주제:두 개의 정수를 매개변수로 받아서 두 수의 차를 반환하는 ㅎ삼수 subtract를 정의하여 4,8,을 매개변수로 함수를 호출한 후 출력
작성일:2017.10.11
작성자:이승현
"""
def subtract(a,b):
    return a-b
print(subtract(4,8))