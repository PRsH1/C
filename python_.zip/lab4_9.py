"""
주제 : 구구단 출력
작성일 : 2017.09.27
작성자 : 이현복
"""
for x in range(1,10):
    print("%d단" %x)
    for a in range(1,10):
        print("%d * %d = %d")