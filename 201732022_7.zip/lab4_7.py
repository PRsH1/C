"""
주제:1부터 사용자로부터 입력받은 수 까지의 약수 출력
작성일:2017.9.25.
작성자:이승현
"""
s=int(input("숫자를 입력하세요:"))#안내문 출력
list=[]#리스트 함수 정의
for num2 in range(1,s+1):#반복문
    list=[]#리스트 초기화
    if s%num2==0:#num2로 나뉘어지면
        print(num2)#num2출력
        for p in range(1,num2+1):#반복문
            if num2%p==0:#p로 나뉘어지면
                list.append(p)#리스트에 추가
        print(list)#리스트 출력

